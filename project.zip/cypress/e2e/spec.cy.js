describe("My first spec", () => {
  it("Passes!", () => {
    expect(true).to.equal(false);
  });
});
